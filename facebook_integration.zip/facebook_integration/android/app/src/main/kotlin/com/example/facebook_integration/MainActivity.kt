package com.example.facebook_integration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
